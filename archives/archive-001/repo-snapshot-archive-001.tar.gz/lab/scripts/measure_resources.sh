#!/usr/bin/env bash
# Mesure simple des ressources d'un process cible (container ou process local).
# À adapter par POC (PID ou nom de container).

echo "Ce script est un stub. À compléter par POC:"
echo "- Soit via 'docker stats'"
echo "- Soit via 'ps', 'top', 'htop', etc."
