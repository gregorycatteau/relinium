# RESULTS – [À REMPLACER : nom du candidat]

## 1. Résumé
- Verdict global (subjectif) : [OK / mitigé / KO]
- Points forts :
- Points faibles :

## 2. Mesures de performance (VPS 2vCPU/4GB si possible)
### Bench lecture – GET /documents?page=1&size=20
- Commande : `hey -n 1000 -c 20 http://localhost:PORT/documents?page=1&size=20`
- p50 :
- p95 :
- req/s :
- Erreurs (4xx/5xx) :

### Bench upload – POST /uploads (fichier 20–50 Mo)
- Durée moyenne :
- Erreurs :
- Observations :

### Ressources
- RAM idle (MiB) :
- RAM peak (MiB) :
- CPU moyen (% estimé) :
- Temps de cold start (s) :

## 3. DX / Ergonomie
- Temps d'installation (lecture POC + setup) :
- Clarté des erreurs :
- Lisibilité du code :

## 4. Correspondance avec SLOs (OBS-0003)
- Latence p95 OK ? [Oui/Non]
- RAM idle dans les seuils ? [Oui/Non]
- Souveraineté (offline) respectée ? [Oui/Non]
- Coût estimé (VPS) :

## 5. Notes pour la matrice RFC-002
- Performance & sobriété (0–5) :
- Sécurité / durcissement (0–5) :
- Souveraineté / local-first (0–5) :
- Maintenabilité / DX / etc. (0–5) :
- Commentaires :

